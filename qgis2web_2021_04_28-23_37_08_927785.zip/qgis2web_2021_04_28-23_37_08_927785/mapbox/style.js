
var styleJSON = {
    "version": 8,
    "name": "qgis2web export",
    "pitch": 0,
    "light": {
        "intensity": 0.2
    },
    "sources": {
        "GoogleSatelite_0": {
            "type": "raster",
            "tiles": ["http://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}"],
            "tileSize": 256
        },
        "GoogleTerrain_1": {
            "type": "raster",
            "tiles": ["https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}"],
            "tileSize": 256
        },
        "GoogleSateliteHybrid_2": {
            "type": "raster",
            "tiles": ["https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}"],
            "tileSize": 256
        },
        "GoogleMaps_3": {
            "type": "raster",
            "tiles": ["https://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}"],
            "tileSize": 256
        },
        "OpenStreetMap_4": {
            "type": "raster",
            "tiles": ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
            "tileSize": 256
        },
        "GoogleRoads_5": {
            "type": "raster",
            "tiles": ["https://mt1.google.com/vt/lyrs=h&x={x}&y={y}&z={z}"],
            "tileSize": 256
        },
        "KecamatanSegedong_6": {
            "type": "geojson",
            "data": json_KecamatanSegedong_6
        }
                    ,
        "DesaSuiPurunKecil_7": {
            "type": "geojson",
            "data": json_DesaSuiPurunKecil_7
        }
                    ,
        "DesaSuiBurung_8": {
            "type": "geojson",
            "data": json_DesaSuiBurung_8
        }
                    ,
        "DesaPenitiBesar_9": {
            "type": "geojson",
            "data": json_DesaPenitiBesar_9
        }
                    ,
        "DesaPenitiDalam_10": {
            "type": "geojson",
            "data": json_DesaPenitiDalam_10
        }
                    },
    "sprite": "",
    "glyphs": "https://glfonts.lukasmartinelli.ch/fonts/{fontstack}/{range}.pbf",
    "layers": [
        {
            "id": "background",
            "type": "background",
            "layout": {},
            "paint": {
                "background-color": "#ffffff"
            }
        },
        {
            "id": "lyr_GoogleSatelite_0_0",
            "type": "raster",
            "source": "GoogleSatelite_0"
        },
        {
            "id": "lyr_GoogleTerrain_1_1",
            "type": "raster",
            "source": "GoogleTerrain_1"
        },
        {
            "id": "lyr_GoogleSateliteHybrid_2_2",
            "type": "raster",
            "source": "GoogleSateliteHybrid_2"
        },
        {
            "id": "lyr_GoogleMaps_3_3",
            "type": "raster",
            "source": "GoogleMaps_3"
        },
        {
            "id": "lyr_OpenStreetMap_4_4",
            "type": "raster",
            "source": "OpenStreetMap_4"
        },
        {
            "id": "lyr_GoogleRoads_5_5",
            "type": "raster",
            "source": "GoogleRoads_5"
        },
        {
            "id": "lyr_KecamatanSegedong_6_0",
            "type": "fill",
            "source": "KecamatanSegedong_6",
            "layout": {},
            "paint": {'fill-opacity': 0.786, 'fill-color': '#c43c39'}
        }
,
        {
            "id": "lyr_DesaSuiPurunKecil_7_0",
            "type": "fill",
            "source": "DesaSuiPurunKecil_7",
            "layout": {},
            "paint": {'fill-opacity': 0.522, 'fill-color': '#e15989'}
        }
,
        {
            "id": "lyr_DesaSuiBurung_8_0",
            "type": "fill",
            "source": "DesaSuiBurung_8",
            "layout": {},
            "paint": {'fill-opacity': 0.452, 'fill-color': '#e5b636'}
        }
,
        {
            "id": "lyr_DesaPenitiBesar_9_0",
            "type": "fill",
            "source": "DesaPenitiBesar_9",
            "layout": {},
            "paint": {'fill-opacity': 0.532, 'fill-color': '#becf50'}
        }
,
        {
            "id": "lyr_DesaPenitiDalam_10_0",
            "type": "fill",
            "source": "DesaPenitiDalam_10",
            "layout": {},
            "paint": {'fill-opacity': 0.556, 'fill-color': '#987db7'}
        }
],
}